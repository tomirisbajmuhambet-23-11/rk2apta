from shapes import Circle, Rectangle

c = Circle(2)
r = Rectangle(3,4)

print(c.area())
print(r.area())
