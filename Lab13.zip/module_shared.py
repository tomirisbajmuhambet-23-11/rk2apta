def shared_utility():
    print("shared working")
