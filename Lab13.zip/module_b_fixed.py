from module_shared import shared_utility

def func_b():
    shared_utility()
