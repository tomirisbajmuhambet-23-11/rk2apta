from module_a import func_a

def func_b():
    func_a()
