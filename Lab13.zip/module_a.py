from module_b import func_b

def func_a():
    func_b()
