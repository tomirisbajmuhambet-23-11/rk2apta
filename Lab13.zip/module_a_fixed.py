from module_shared import shared_utility

def func_a():
    shared_utility()
